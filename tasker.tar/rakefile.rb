require "./tasker/kraken_tasker"
require "sinatra/activerecord/rake"

